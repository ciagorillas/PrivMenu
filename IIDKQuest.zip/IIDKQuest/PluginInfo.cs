﻿namespace IIDKQuest
{
    internal class PluginInfo
    {
        // SATURN DID NOT MAKE THIS MENU, HARMONY DID!
        public const string GUID = "org.harmony.gorillatag.untitled";
        public const string Name = "Harmonys Temp";
        public const string Description = "Created by harmony with love <3";
        public const string Version = "1.0.0";
        // SATURN DID NOT MAKE THIS MENU, HARMONY DID!
    }
}
